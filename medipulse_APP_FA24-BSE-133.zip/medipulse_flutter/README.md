# MediPulse – Medical Appointment Booking (Flutter)

## Features
- Animated splash screen
- Home dashboard: time-aware greeting, next upcoming visit, specialties, top-rated doctors
- Doctors: live search + specialty filters + favourites
- Booking flow: real upcoming dates, unavailable slots, summary with live billing, confirmation dialog
- Visits: Upcoming / Past / Cancelled tabs, reschedule, cancel (with confirm), book again
- Profile: reminder toggle and placeholders

## Run locally
    flutter create .
    flutter pub get
    flutter run

## Build the APK
Locally:

    flutter build apk --release
    # → build/app/outputs/flutter-apk/app-release.apk

No Flutter installed? Push this folder to a GitHub repo. The included workflow
(.github/workflows/build_apk.yml) builds the APK. Download it from
Actions → latest run → Artifacts → medipulse-apk.

## Note
Data is in-memory sample data. No backend, authentication, payments or real
doctor availability yet.
