import 'package:flutter/material.dart';

void main() => runApp(const MediPulseApp());

// ───────────────────────── Design tokens ─────────────────────────
const teal = Color(0xFF00685F);
const tealLight = Color(0xFFE1F5F1);
const ink = Color(0xFF17233B);
const muted = Color(0xFF697783);
const canvas = Color(0xFFF8F9FD);
const line = Color(0xFFE9EDF3);
const green = Color(0xFF16865D);
const amber = Color(0xFFFFB547);
const danger = Color(0xFFC62828);

const _wd = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const _mo = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
String fmtDate(DateTime d) => '${_wd[d.weekday - 1]}, ${_mo[d.month - 1]} ${d.day}, ${d.year}';
String greeting() {
  final h = DateTime.now().hour;
  return h < 12 ? 'Good morning' : (h < 17 ? 'Good afternoon' : 'Good evening');
}

void toast(BuildContext c, String msg) => ScaffoldMessenger.of(c)
  ..hideCurrentSnackBar()
  ..showSnackBar(SnackBar(
    content: Text(msg),
    behavior: SnackBarBehavior.floating,
    backgroundColor: ink,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  ));

// ───────────────────────── App ─────────────────────────
class MediPulseApp extends StatelessWidget {
  const MediPulseApp({super.key});

  @override
  Widget build(BuildContext context) {
    final btnShape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(14));
    return MaterialApp(
      title: 'MediPulse',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: canvas,
        colorScheme: ColorScheme.fromSeed(seedColor: teal, primary: teal),
        appBarTheme: const AppBarTheme(
            backgroundColor: canvas, foregroundColor: ink, elevation: 0, scrolledUnderElevation: 0),
        filledButtonTheme: FilledButtonThemeData(
            style: FilledButton.styleFrom(
                backgroundColor: teal, minimumSize: const Size.fromHeight(52), shape: btnShape)),
        outlinedButtonTheme: OutlinedButtonThemeData(
            style: OutlinedButton.styleFrom(
                foregroundColor: teal,
                side: const BorderSide(color: Color(0xFFCFE3E0)),
                minimumSize: const Size(0, 46),
                shape: btnShape)),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
      home: const SplashPage(),
    );
  }
}

// ───────────────────────── Models ─────────────────────────
class Doctor {
  final String id, name, category, title, experience, about, clinic, room;
  final int fee, reviews, patients;
  final double rating;
  final Color color;
  const Doctor({
    required this.id, required this.name, required this.category, required this.title,
    required this.experience, required this.about, required this.clinic, required this.room,
    required this.fee, required this.reviews, required this.patients, required this.rating,
    required this.color,
  });
  String get specialty => '$category • $title';
}

const doctors = [
  Doctor(id: 'd1', name: 'Dr. Elena Rostova, MD', category: 'Cardiology', title: 'Specialist', experience: '12 years',
      about: 'Board-certified cardiologist focused on preventive heart care, hypertension and long-term cardiac wellness.',
      clinic: 'St. Jude Heart Center', room: 'Building 3, Suite 402', fee: 85, reviews: 128, patients: 2400, rating: 4.9, color: Color(0xFFE9D8D0)),
  Doctor(id: 'd2', name: 'Dr. Julian Hayes', category: 'Dermatology', title: 'Consultant', experience: '8 years',
      about: 'Treats acne, eczema and skin allergies with evidence-based, personalised treatment plans.',
      clinic: 'ClearSkin Clinic', room: 'Floor 2, Room 210', fee: 70, reviews: 96, patients: 1800, rating: 4.8, color: Color(0xFFD9E8E7)),
  Doctor(id: 'd3', name: 'Dr. Marcus Vance', category: 'General', title: 'Physician', experience: '10 years',
      about: 'Family physician offering routine checkups, chronic-condition management and clear, friendly guidance.',
      clinic: 'MediPulse Family Care', room: 'Ground Floor, Room 5', fee: 60, reviews: 214, patients: 3100, rating: 4.9, color: Color(0xFFE6DFD2)),
  Doctor(id: 'd4', name: 'Dr. Priya Nair', category: 'Pediatrics', title: 'Specialist', experience: '9 years',
      about: 'Caring pediatrician for newborns through teens, vaccinations and developmental check-ins.',
      clinic: 'Little Steps Children Clinic', room: 'Floor 1, Room 108', fee: 65, reviews: 172, patients: 2700, rating: 4.9, color: Color(0xFFE3DCEB)),
  Doctor(id: 'd5', name: 'Dr. Daniel Brooks', category: 'Cardiology', title: 'Consultant', experience: '15 years',
      about: 'Interventional cardiology consultant with a focus on rhythm disorders and cardiac rehabilitation.',
      clinic: 'St. Jude Heart Center', room: 'Building 1, Suite 120', fee: 95, reviews: 301, patients: 4200, rating: 4.7, color: Color(0xFFD6E3EE)),
  Doctor(id: 'd6', name: 'Dr. Sofia Marin', category: 'Dermatology', title: 'Specialist', experience: '6 years',
      about: 'Cosmetic and medical dermatology, including skin-cancer screening and laser therapy.',
      clinic: 'ClearSkin Clinic', room: 'Floor 3, Room 305', fee: 75, reviews: 88, patients: 1300, rating: 4.8, color: Color(0xFFEBDDDD)),
];

const categories = ['General', 'Cardiology', 'Dermatology', 'Pediatrics'];
const categoryIcons = [Icons.favorite, Icons.monitor_heart, Icons.face, Icons.child_care];

enum Status { upcoming, completed, cancelled }

class Booking {
  Doctor doctor;
  DateTime date;
  String time, reason, patient;
  Status status;
  Booking({
    required this.doctor, required this.date, required this.time,
    this.reason = 'Annual Health Checkup', this.patient = 'Myself (Sarah)',
    this.status = Status.upcoming,
  });
}

// ───────────────────────── Splash ─────────────────────────
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..forward();

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            transitionDuration: const Duration(milliseconds: 450),
            pageBuilder: (_, __, ___) => const MainShell(),
            transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
          ));
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: teal,
        body: Center(
          child: FadeTransition(
            opacity: _c,
            child: ScaleTransition(
              scale: CurvedAnimation(parent: _c, curve: Curves.easeOutBack),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 92, height: 92,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)),
                  child: const Icon(Icons.local_hospital, color: teal, size: 54),
                ),
                const SizedBox(height: 20),
                const Text('MediPulse',
                    style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: .5)),
                const SizedBox(height: 6),
                const Text('Care, scheduled simply', style: TextStyle(color: Colors.white70)),
              ]),
            ),
          ),
        ),
      );
}

// ───────────────────────── Shell & state ─────────────────────────
class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  String query = '';
  String? specialty;
  final Set<String> favorites = {};
  final List<Booking> bookings = [
    Booking(doctor: doctors[2], date: DateTime.now().add(const Duration(days: 1)), time: '10:30 AM'),
    Booking(doctor: doctors[0], date: DateTime.now().subtract(const Duration(days: 20)), time: '02:00 PM', status: Status.completed),
    Booking(doctor: doctors[1], date: DateTime.now().subtract(const Duration(days: 45)), time: '09:45 AM', status: Status.completed),
  ];

  Booking? get next {
    final up = bookings.where((b) => b.status == Status.upcoming).toList()
      ..sort((a, b) => a.date.compareTo(b.date));
    return up.isEmpty ? null : up.first;
  }

  void toggleFav(Doctor d) => setState(() => favorites.contains(d.id) ? favorites.remove(d.id) : favorites.add(d.id));

  void search(String q, {String? cat}) => setState(() {
        query = q;
        specialty = cat;
        tab = 1;
      });

  /// Starts the booking flow. Pass [existing] to reschedule instead.
  void book(Doctor d, {Booking? existing}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => DoctorPage(
                  doctor: d,
                  reschedule: existing != null,
                  onContinue: (date, time) {
                    final draft = Booking(
                      doctor: d, date: date, time: time,
                      reason: existing?.reason ?? 'Annual Health Checkup',
                      patient: existing?.patient ?? 'Myself (Sarah)',
                    );
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => SummaryPage(
                                  booking: draft,
                                  reschedule: existing != null,
                                  onConfirm: () {
                                    setState(() {
                                      if (existing != null) {
                                        existing.date = date;
                                        existing.time = time;
                                        existing.reason = draft.reason;
                                        existing.patient = draft.patient;
                                      } else {
                                        bookings.insert(0, draft);
                                      }
                                      tab = 2;
                                    });
                                    Navigator.popUntil(context, (r) => r.isFirst);
                                    _success(draft);
                                  },
                                )));
                  },
                )));
  }

  void _success(Booking b) => showDialog(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 8),
            const CircleAvatar(radius: 32, backgroundColor: tealLight, child: Icon(Icons.check, color: teal, size: 38)),
            const SizedBox(height: 16),
            const Text('Appointment Confirmed', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 8),
            Text('${b.doctor.name}\n${fmtDate(b.date)} at ${b.time}',
                textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.5)),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done', style: TextStyle(color: teal)))
          ],
        ),
      );

  void cancel(Booking b) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Cancel appointment?'),
        content: Text('Your visit with ${b.doctor.name} on ${fmtDate(b.date)} will be cancelled.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Keep it')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Cancel visit', style: TextStyle(color: danger))),
        ],
      ),
    );
    if (ok == true && mounted) {
      setState(() => b.status = Status.cancelled);
      toast(context, 'Appointment cancelled');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        next: next, favorites: favorites, onDoctor: book, onFav: toggleFav, onSearch: search,
        onReschedule: (b) => book(b.doctor, existing: b),
        onSeeAll: () => setState(() => tab = 2),
        onSeeDoctors: () => search('', cat: null),
      ),
      DoctorsPage(
        query: query, specialty: specialty, favorites: favorites, onDoctor: book, onFav: toggleFav,
        onChanged: (q, c) => setState(() {
          query = q;
          specialty = c;
        }),
      ),
      AppointmentsPage(
        bookings: bookings, onCancel: cancel,
        onReschedule: (b) => book(b.doctor, existing: b),
        onRebook: (d) => book(d),
        onBook: () => setState(() => tab = 1),
      ),
      const ProfilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        backgroundColor: Colors.white,
        indicatorColor: tealLight,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.medical_services_outlined), selectedIcon: Icon(Icons.medical_services), label: 'Doctors'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Visits'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

// ───────────────────────── Home ─────────────────────────
class HomePage extends StatelessWidget {
  final Booking? next;
  final Set<String> favorites;
  final ValueChanged<Doctor> onDoctor, onFav;
  final void Function(String q, {String? cat}) onSearch;
  final ValueChanged<Booking> onReschedule;
  final VoidCallback onSeeAll, onSeeDoctors;
  const HomePage({
    super.key, required this.next, required this.favorites, required this.onDoctor, required this.onFav,
    required this.onSearch, required this.onReschedule, required this.onSeeAll, required this.onSeeDoctors,
  });

  @override
  Widget build(BuildContext context) {
    final top = [...doctors]..sort((a, b) => b.rating.compareTo(a.rating));
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
      children: [
        const BrandHeader(),
        const SizedBox(height: 22),
        Row(children: [
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${greeting()}, Sarah',
                style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 5),
            const Text('How are you feeling today?', style: TextStyle(color: muted)),
          ])),
        ]),
        const SizedBox(height: 18),
        TextField(
          textInputAction: TextInputAction.search,
          onSubmitted: (v) => onSearch(v),
          decoration: const InputDecoration(
            hintText: 'Search doctor, specialty, clinic...',
            prefixIcon: Icon(Icons.search, color: muted),
            suffixIcon: Icon(Icons.tune, color: teal),
          ),
        ),
        const SizedBox(height: 22),
        SectionTitle('Upcoming Visit', trailing: 'View all', onTrailing: onSeeAll),
        const SizedBox(height: 10),
        if (next == null)
          CardBox(
              child: Column(children: [
            const Text('No upcoming visits', style: TextStyle(fontWeight: FontWeight.w700, color: ink)),
            const SizedBox(height: 4),
            const Text('Book a doctor in just a few taps.', style: TextStyle(color: muted)),
            TextButton(onPressed: onSeeDoctors, child: const Text('Find a doctor')),
          ]))
        else
          CardBox(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.circle, size: 9, color: teal),
              const SizedBox(width: 6),
              const Text('In-Clinic Visit', style: TextStyle(color: teal, fontWeight: FontWeight.w700)),
              const Spacer(),
              Text('${fmtDate(next!.date)}, ${next!.time}', style: const TextStyle(color: muted, fontSize: 12)),
            ]),
            const SizedBox(height: 13),
            DoctorTile(doctor: next!.doctor, compact: true, onTap: () {}),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                  child: OutlinedButton.icon(
                      onPressed: () => toast(context, 'Directions to ${next!.doctor.clinic}'),
                      icon: const Icon(Icons.directions, size: 17),
                      label: const Text('Directions'))),
              const SizedBox(width: 8),
              Expanded(
                  child: OutlinedButton.icon(
                      onPressed: () => onReschedule(next!),
                      icon: const Icon(Icons.edit_calendar, size: 17),
                      label: const Text('Reschedule'))),
            ]),
          ])),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF00685F), Color(0xFF0A8F83)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Need quick medical advice?',
                style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Connect with an experienced general physician through a secure video consultation.',
                style: TextStyle(color: Colors.white70, height: 1.4)),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  backgroundColor: Colors.white, foregroundColor: teal, minimumSize: const Size(0, 46)),
              onPressed: () => onDoctor(doctors[2]),
              icon: const Icon(Icons.video_call),
              label: const Text('Start Video Consult'),
            ),
          ]),
        ),
        const SizedBox(height: 22),
        SectionTitle('Explore Specialties', trailing: '${categories.length} fields'),
        const SizedBox(height: 12),
        SizedBox(
          height: 92,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            itemBuilder: (_, i) => SpecialtyChip(
              icon: categoryIcons[i], label: categories[i],
              count: '${doctors.where((d) => d.category == categories[i]).length} Doctors',
              onTap: () => onSearch('', cat: categories[i]),
            ),
          ),
        ),
        const SizedBox(height: 20),
        SectionTitle('Top Rated Doctors', trailing: 'See all', onTrailing: onSeeDoctors),
        const SizedBox(height: 8),
        ...top.take(3).map((d) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: CardBox(
                  child: DoctorTile(
                      doctor: d, onTap: () => onDoctor(d), favorite: favorites.contains(d.id), onFav: () => onFav(d))),
            )),
      ],
    );
  }
}

// ───────────────────────── Doctors (search + filter) ─────────────────────────
class DoctorsPage extends StatefulWidget {
  final String query;
  final String? specialty;
  final Set<String> favorites;
  final ValueChanged<Doctor> onDoctor, onFav;
  final void Function(String q, String? cat) onChanged;
  const DoctorsPage({
    super.key, required this.query, required this.specialty, required this.favorites,
    required this.onDoctor, required this.onFav, required this.onChanged,
  });
  @override
  State<DoctorsPage> createState() => _DoctorsPageState();
}

class _DoctorsPageState extends State<DoctorsPage> {
  late final TextEditingController ctrl = TextEditingController(text: widget.query);

  @override
  void didUpdateWidget(covariant DoctorsPage old) {
    super.didUpdateWidget(old);
    if (ctrl.text != widget.query) ctrl.text = widget.query;
  }

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.query.toLowerCase().trim();
    final list = doctors.where((d) {
      final okCat = widget.specialty == null || d.category == widget.specialty;
      final okQ = q.isEmpty ||
          d.name.toLowerCase().contains(q) ||
          d.specialty.toLowerCase().contains(q) ||
          d.clinic.toLowerCase().contains(q);
      return okCat && okQ;
    }).toList();
    return ListView(padding: const EdgeInsets.all(18), children: [
      const BrandHeader(title: 'Find Doctors'),
      const SizedBox(height: 18),
      const Text('Find the right specialist', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: ink)),
      const SizedBox(height: 14),
      TextField(
        controller: ctrl,
        onChanged: (v) => widget.onChanged(v, widget.specialty),
        decoration: InputDecoration(
          hintText: 'Search by name, specialty or clinic',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: q.isEmpty
              ? null
              : IconButton(icon: const Icon(Icons.close), onPressed: () => widget.onChanged('', widget.specialty)),
        ),
      ),
      const SizedBox(height: 12),
      SizedBox(
        height: 40,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          for (final c in [null, ...categories])
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(c ?? 'All'),
                selected: widget.specialty == c,
                onSelected: (_) => widget.onChanged(widget.query, c),
                selectedColor: tealLight,
                labelStyle: TextStyle(color: widget.specialty == c ? teal : ink, fontWeight: FontWeight.w600),
                side: BorderSide(color: widget.specialty == c ? teal : const Color(0xFFE1E6EC)),
              ),
            ),
        ]),
      ),
      const SizedBox(height: 14),
      Text('${list.length} doctor${list.length == 1 ? '' : 's'} available',
          style: const TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 10),
      if (list.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 50),
          child: Column(children: [
            Icon(Icons.search_off, size: 48, color: muted),
            SizedBox(height: 10),
            Text('No doctors match your search', style: TextStyle(color: muted)),
          ]),
        ),
      ...list.map((d) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: CardBox(
                child: DoctorTile(
                    doctor: d, onTap: () => widget.onDoctor(d),
                    favorite: widget.favorites.contains(d.id), onFav: () => widget.onFav(d))),
          )),
    ]);
  }
}

// ───────────────────────── Doctor details ─────────────────────────
class DoctorPage extends StatefulWidget {
  final Doctor doctor;
  final bool reschedule;
  final void Function(DateTime date, String time) onContinue;
  const DoctorPage({super.key, required this.doctor, required this.onContinue, this.reschedule = false});
  @override
  State<DoctorPage> createState() => _DoctorPageState();
}

class _DoctorPageState extends State<DoctorPage> {
  static const times = ['09:00 AM', '09:45 AM', '11:15 AM', '02:00 PM', '03:30 PM', '04:15 PM'];
  late final List<DateTime> dates = List.generate(7, (i) => DateTime.now().add(Duration(days: i + 1)));
  int day = 0;
  late String time = _firstFree();

  // Demo availability: some slots are shown as already booked.
  bool booked(int d, int i) => (dates[d].day + i) % 4 == 0;
  String _firstFree() {
    for (var i = 0; i < times.length; i++) {
      if (!booked(day, i)) return times[i];
    }
    return times.first;
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.doctor;
    return Scaffold(
      appBar: AppBar(
          title: Text(widget.reschedule ? 'Reschedule' : 'Doctor Details',
              style: const TextStyle(fontWeight: FontWeight.bold))),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton(
            onPressed: () => widget.onContinue(dates[day], time),
            child: Text('Continue  •  \$${d.fee}', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        ),
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 24), children: [
        CardBox(
          child: Column(children: [
            Hero(
              tag: 'avatar-${d.id}',
              child: CircleAvatar(radius: 43, backgroundColor: d.color, child: const Icon(Icons.person, size: 52, color: Colors.white)),
            ),
            const SizedBox(height: 12),
            Text(d.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 4),
            Text(d.specialty, style: const TextStyle(color: muted)),
            const SizedBox(height: 14),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              Stat(value: d.experience.split(' ').first + ' yrs', label: 'Experience'),
              Stat(value: '${(d.patients / 1000).toStringAsFixed(1)}k+', label: 'Patients'),
              Stat(value: '${d.rating}', label: 'Rating'),
            ]),
            const Divider(height: 26),
            Row(children: [
              const Icon(Icons.star, color: amber, size: 18),
              Text(' ${d.rating} ', style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('(${d.reviews} reviews)', style: const TextStyle(color: muted)),
              const Spacer(),
              Text('\$${d.fee} / visit', style: const TextStyle(color: teal, fontWeight: FontWeight.bold)),
            ]),
          ]),
        ),
        const SizedBox(height: 18),
        const SectionTitle('About Doctor'),
        const SizedBox(height: 8),
        Text(d.about, style: const TextStyle(color: muted, height: 1.5)),
        const SizedBox(height: 20),
        const SectionTitle('Select Date'),
        const SizedBox(height: 12),
        SizedBox(
          height: 70,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: dates.length,
            itemBuilder: (_, i) {
              final sel = day == i;
              return GestureDetector(
                onTap: () => setState(() {
                  day = i;
                  if (booked(day, times.indexOf(time))) time = _firstFree();
                }),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  width: 58,
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: sel ? teal : Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: sel ? teal : const Color(0xFFE5EAF0)),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(_wd[dates[i].weekday - 1], style: TextStyle(color: sel ? Colors.white70 : muted, fontSize: 11)),
                    const SizedBox(height: 3),
                    Text('${dates[i].day}', style: TextStyle(color: sel ? Colors.white : ink, fontWeight: FontWeight.w800, fontSize: 17)),
                  ]),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle('Available Time Slots'),
        const SizedBox(height: 10),
        Wrap(spacing: 9, runSpacing: 9, children: [
          for (var i = 0; i < times.length; i++)
            ChoiceChip(
              label: Text(times[i]),
              selected: time == times[i],
              onSelected: booked(day, i) ? null : (_) => setState(() => time = times[i]),
              selectedColor: tealLight,
              labelStyle: TextStyle(
                  color: booked(day, i) ? const Color(0xFFB0B8C0) : (time == times[i] ? teal : ink),
                  decoration: booked(day, i) ? TextDecoration.lineThrough : null,
                  fontWeight: FontWeight.w600),
              side: BorderSide(color: time == times[i] ? teal : const Color(0xFFE1E6EC)),
            ),
        ]),
        const SizedBox(height: 18),
        CardBox(child: InfoLine(icon: Icons.location_on, title: d.clinic, subtitle: d.room)),
      ]),
    );
  }
}

// ───────────────────────── Summary ─────────────────────────
class SummaryPage extends StatefulWidget {
  final Booking booking;
  final bool reschedule;
  final VoidCallback onConfirm;
  const SummaryPage({super.key, required this.booking, required this.onConfirm, this.reschedule = false});
  @override
  State<SummaryPage> createState() => _SummaryPageState();
}

class _SummaryPageState extends State<SummaryPage> {
  bool agreed = true;

  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    final fee = b.doctor.fee.toDouble();
    final covered = (fee * 0.65).roundToDouble();
    const digital = 2.5;
    final total = fee - covered + digital;
    String m(double v) => '\$${v.toStringAsFixed(2)}';
    return Scaffold(
      appBar: AppBar(title: const Text('Appointment Summary', style: TextStyle(fontWeight: FontWeight.bold))),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton.icon(
            onPressed: agreed ? widget.onConfirm : null,
            icon: const Icon(Icons.lock_outline),
            label: Text(widget.reschedule ? 'Confirm New Time' : 'Confirm & Schedule'),
          ),
        ),
      ),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        const Text('STEP 2 OF 3', style: TextStyle(color: teal, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 8),
        ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: const LinearProgressIndicator(value: .66, minHeight: 6, color: teal, backgroundColor: tealLight)),
        const SizedBox(height: 20),
        const SectionTitle('Review Appointment'),
        const SizedBox(height: 10),
        CardBox(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            DoctorTile(doctor: b.doctor, compact: true, onTap: () {}),
            const Divider(height: 22),
            InfoLine(icon: Icons.calendar_today, title: fmtDate(b.date), subtitle: 'In-Clinic Consultation'),
            const SizedBox(height: 10),
            InfoLine(icon: Icons.access_time, title: b.time, subtitle: '50 min appointment'),
            const SizedBox(height: 10),
            InfoLine(icon: Icons.location_on, title: b.doctor.clinic, subtitle: b.doctor.room),
          ]),
        ),
        const SizedBox(height: 18),
        const SectionTitle('Patient Details'),
        const SizedBox(height: 8),
        CardBox(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Who is this visit for?', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: b.patient,
              items: const [
                DropdownMenuItem(value: 'Myself (Sarah)', child: Text('Myself (Sarah)')),
                DropdownMenuItem(value: 'Family Member', child: Text('Family Member')),
              ],
              onChanged: (v) => setState(() => b.patient = v ?? b.patient),
            ),
            const SizedBox(height: 12),
            const Text('Reason for Visit', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: b.reason,
              items: const [
                DropdownMenuItem(value: 'Annual Health Checkup', child: Text('Annual Health Checkup')),
                DropdownMenuItem(value: 'Follow-up Visit', child: Text('Follow-up Visit')),
                DropdownMenuItem(value: 'New Symptoms', child: Text('New Symptoms')),
              ],
              onChanged: (v) => setState(() => b.reason = v ?? b.reason),
            ),
          ]),
        ),
        const SizedBox(height: 18),
        const SectionTitle('Insurance & Billing'),
        const SizedBox(height: 8),
        CardBox(
          child: Column(children: [
            const InfoLine(icon: Icons.verified_user, title: 'BlueCross Health Plan', subtitle: 'Insurance verified (demo)'),
            const Divider(height: 22),
            BillLine(label: 'Consultation Fee', value: m(fee)),
            BillLine(label: 'Insurance Co-Pay', value: '-${m(covered)}'),
            BillLine(label: 'MediPulse Digital Care Fee', value: m(digital)),
            const Divider(height: 18),
            BillLine(label: 'Total Due Today', value: m(total), strong: true),
          ]),
        ),
        const SizedBox(height: 10),
        CheckboxListTile(
          value: agreed,
          onChanged: (v) => setState(() => agreed = v ?? false),
          activeColor: teal,
          contentPadding: EdgeInsets.zero,
          controlAffinity: ListTileControlAffinity.leading,
          title: const Text('I agree to the appointment and cancellation policy.',
              style: TextStyle(color: muted, fontSize: 12)),
        ),
      ]),
    );
  }
}

// ───────────────────────── Appointments ─────────────────────────
class AppointmentsPage extends StatefulWidget {
  final List<Booking> bookings;
  final ValueChanged<Booking> onCancel, onReschedule;
  final ValueChanged<Doctor> onRebook;
  final VoidCallback onBook;
  const AppointmentsPage({
    super.key, required this.bookings, required this.onCancel, required this.onReschedule,
    required this.onRebook, required this.onBook,
  });
  @override
  State<AppointmentsPage> createState() => _AppointmentsPageState();
}

class _AppointmentsPageState extends State<AppointmentsPage> {
  Status seg = Status.upcoming;

  int count(Status s) => widget.bookings.where((b) => b.status == s).length;

  @override
  Widget build(BuildContext context) {
    final list = widget.bookings.where((b) => b.status == seg).toList()
      ..sort((a, b) => seg == Status.upcoming ? a.date.compareTo(b.date) : b.date.compareTo(a.date));
    return ListView(padding: const EdgeInsets.all(18), children: [
      const BrandHeader(title: 'Appointments'),
      const SizedBox(height: 18),
      const Text('My Appointments', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: ink)),
      const Text('Manage your scheduled visits', style: TextStyle(color: muted)),
      const SizedBox(height: 16),
      SizedBox(
        width: double.infinity,
        child: SegmentedButton<Status>(
          showSelectedIcon: false,
          segments: [
            ButtonSegment(value: Status.upcoming, label: Text('Upcoming ${count(Status.upcoming)}')),
            ButtonSegment(value: Status.completed, label: Text('Past ${count(Status.completed)}')),
            ButtonSegment(value: Status.cancelled, label: Text('Cancelled ${count(Status.cancelled)}')),
          ],
          selected: {seg},
          onSelectionChanged: (s) => setState(() => seg = s.first),
          style: SegmentedButton.styleFrom(
              selectedBackgroundColor: tealLight, selectedForegroundColor: teal,
              backgroundColor: Colors.white, visualDensity: VisualDensity.compact),
        ),
      ),
      const SizedBox(height: 16),
      if (list.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 40),
          child: Column(children: [
            Icon(Icons.event_busy, size: 48, color: muted),
            SizedBox(height: 10),
            Text('Nothing here yet', style: TextStyle(color: muted)),
          ]),
        ),
      ...list.map((b) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: CardBox(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: DoctorTile(doctor: b.doctor, compact: true, onTap: () {})),
                  StatusBadge(b.status),
                ]),
                const Divider(height: 22),
                InfoLine(icon: Icons.calendar_today, title: fmtDate(b.date), subtitle: '${b.time} • ${b.reason}'),
                const SizedBox(height: 10),
                InfoLine(icon: Icons.location_on, title: b.doctor.clinic, subtitle: b.doctor.room),
                const SizedBox(height: 12),
                if (b.status == Status.upcoming)
                  Row(children: [
                    Expanded(child: OutlinedButton(onPressed: () => widget.onReschedule(b), child: const Text('Reschedule'))),
                    const SizedBox(width: 8),
                    Expanded(
                        child: OutlinedButton(
                            style: OutlinedButton.styleFrom(foregroundColor: danger, side: const BorderSide(color: Color(0xFFF1C9C9))),
                            onPressed: () => widget.onCancel(b),
                            child: const Text('Cancel'))),
                  ])
                else
                  OutlinedButton(onPressed: () => widget.onRebook(b.doctor), child: const Text('Book again')),
              ]),
            ),
          )),
      const SizedBox(height: 6),
      FilledButton.icon(onPressed: widget.onBook, icon: const Icon(Icons.add), label: const Text('Book New Appointment')),
    ]);
  }
}

// ───────────────────────── Profile ─────────────────────────
class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool notify = true;

  @override
  Widget build(BuildContext context) {
    void soon(String s) => toast(context, '$s – coming soon');
    return ListView(padding: const EdgeInsets.all(18), children: [
      const BrandHeader(title: 'Profile'),
      const SizedBox(height: 25),
      const Center(child: CircleAvatar(radius: 42, backgroundColor: tealLight, child: Icon(Icons.person, color: teal, size: 48))),
      const SizedBox(height: 12),
      const Center(child: Text('Sarah Johnson', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: ink))),
      const Center(child: Text('sarah.j@example.com', style: TextStyle(color: muted))),
      const SizedBox(height: 28),
      CardBox(
        child: Column(children: [
          ProfileRow(icon: Icons.person_outline, label: 'Personal Information', onTap: () => soon('Personal information')),
          const Divider(),
          ProfileRow(icon: Icons.shield_outlined, label: 'Insurance & Billing', onTap: () => soon('Insurance')),
          const Divider(),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            secondary: const Icon(Icons.notifications_outlined, color: teal),
            title: const Text('Appointment reminders', style: TextStyle(fontWeight: FontWeight.w600)),
            value: notify,
            activeColor: teal,
            onChanged: (v) => setState(() => notify = v),
          ),
          const Divider(),
          ProfileRow(icon: Icons.help_outline, label: 'Help & Support', onTap: () => soon('Support')),
        ]),
      ),
      const SizedBox(height: 18),
      OutlinedButton.icon(
          style: OutlinedButton.styleFrom(foregroundColor: danger, side: const BorderSide(color: Color(0xFFF1C9C9))),
          onPressed: () => soon('Sign out'),
          icon: const Icon(Icons.logout),
          label: const Text('Sign out')),
    ]);
  }
}

// ───────────────────────── Shared widgets ─────────────────────────
class BrandHeader extends StatelessWidget {
  final String title;
  const BrandHeader({super.key, this.title = 'Home'});
  @override
  Widget build(BuildContext context) => Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(color: teal, borderRadius: BorderRadius.circular(11)),
          child: const Icon(Icons.local_hospital, color: Colors.white, size: 21),
        ),
        const SizedBox(width: 9),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MediPulse', style: TextStyle(color: teal, fontWeight: FontWeight.w800, fontSize: 17, height: 1.1)),
          Text(title == 'Home' ? 'Healthcare appointments' : title, style: const TextStyle(color: muted, fontSize: 10)),
        ]),
        const Spacer(),
        IconButton(
            onPressed: () => toast(context, 'You are all caught up'),
            icon: const Icon(Icons.notifications_none, color: muted)),
        const CircleAvatar(radius: 17, backgroundColor: tealLight, child: Icon(Icons.person, color: teal, size: 19)),
      ]);
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? trailing;
  final VoidCallback? onTrailing;
  const SectionTitle(this.title, {super.key, this.trailing, this.onTrailing});
  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(child: Text(title, style: const TextStyle(color: ink, fontWeight: FontWeight.w800, fontSize: 17))),
        if (trailing != null)
          InkWell(
            onTap: onTrailing,
            child: Text(trailing!, style: const TextStyle(color: teal, fontWeight: FontWeight.w700, fontSize: 12)),
          ),
      ]);
}

class CardBox extends StatelessWidget {
  final Widget child;
  const CardBox({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: line),
          boxShadow: const [BoxShadow(color: Color(0x0A17233B), blurRadius: 14, offset: Offset(0, 5))],
        ),
        child: child,
      );
}

class DoctorTile extends StatelessWidget {
  final Doctor doctor;
  final VoidCallback onTap;
  final bool compact, favorite;
  final VoidCallback? onFav;
  const DoctorTile({
    super.key, required this.doctor, required this.onTap, this.compact = false, this.favorite = false, this.onFav,
  });
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Row(children: [
          CircleAvatar(
              radius: compact ? 25 : 29,
              backgroundColor: doctor.color,
              child: Icon(Icons.person, size: compact ? 29 : 34, color: Colors.white)),
          const SizedBox(width: 11),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(doctor.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, color: ink, fontSize: 14)),
            const SizedBox(height: 3),
            Text(doctor.specialty, style: const TextStyle(color: muted, fontSize: 11)),
            const SizedBox(height: 4),
            Row(children: [
              const Icon(Icons.star, size: 14, color: amber),
              Text(' ${doctor.rating}  •  ${doctor.experience}', style: const TextStyle(color: muted, fontSize: 11)),
            ]),
          ])),
          if (!compact)
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              if (onFav != null)
                GestureDetector(
                  onTap: onFav,
                  child: Icon(favorite ? Icons.favorite : Icons.favorite_border,
                      size: 20, color: favorite ? danger : muted),
                ),
              const SizedBox(height: 6),
              Text('\$${doctor.fee}', style: const TextStyle(color: teal, fontWeight: FontWeight.w800)),
            ]),
        ]),
      );
}

class SpecialtyChip extends StatelessWidget {
  final IconData icon;
  final String label, count;
  final VoidCallback onTap;
  const SpecialtyChip({super.key, required this.icon, required this.label, required this.count, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 104,
          margin: const EdgeInsets.only(right: 9),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: line)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: teal),
            const SizedBox(height: 5),
            Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)),
            Text(count, style: const TextStyle(color: muted, fontSize: 9)),
          ]),
        ),
      );
}

class StatusBadge extends StatelessWidget {
  final Status status;
  const StatusBadge(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    final (label, color, icon) = switch (status) {
      Status.upcoming => ('Confirmed', green, Icons.check_circle),
      Status.completed => ('Completed', muted, Icons.task_alt),
      Status.cancelled => ('Cancelled', danger, Icons.cancel),
    };
    return Row(children: [
      Icon(icon, color: color, size: 16),
      Text(' $label', style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
    ]);
  }
}

class Stat extends StatelessWidget {
  final String value, label;
  const Stat({super.key, required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
        Text(value, style: const TextStyle(color: teal, fontWeight: FontWeight.w800, fontSize: 17)),
        Text(label, style: const TextStyle(color: muted, fontSize: 10)),
      ]);
}

class InfoLine extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const InfoLine({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Row(children: [
        Container(
          width: 34, height: 34,
          decoration: BoxDecoration(color: tealLight, borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: teal, size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: ink)),
          Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
        ])),
      ]);
}

class BillLine extends StatelessWidget {
  final String label, value;
  final bool strong;
  const BillLine({super.key, required this.label, required this.value, this.strong = false});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(children: [
          Expanded(child: Text(label, style: TextStyle(color: strong ? ink : muted, fontWeight: strong ? FontWeight.w800 : FontWeight.normal))),
          Text(value, style: TextStyle(color: strong ? teal : ink, fontWeight: FontWeight.w800)),
        ]),
      );
}

class ProfileRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const ProfileRow({super.key, required this.icon, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(children: [
            Icon(icon, color: teal),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
            const Icon(Icons.chevron_right, color: muted),
          ]),
        ),
      );
}
